import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk

SUPPORTED = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff")


class TrafficCropper:
    def __init__(self, root):
        self.root = root
        self.root.title("Traffic Screenshot Cropper")
        self.root.geometry("1120x820")
        self.root.minsize(850, 650)

        self.input_dir = ""
        self.output_dir = ""
        self.files = []
        self.index = 0
        self.current_image = None
        self.preview_photo = None
        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.display_w = 1
        self.display_h = 1
        self.start_xy = None
        self.rect_id = None
        self.crop_rel = None  # normalized (left, top, right, bottom), 0..1

        top = ttk.Frame(root, padding=10)
        top.pack(fill="x")
        ttk.Button(top, text="1. Pilih Folder Gambar", command=self.choose_input).pack(side="left")
        self.folder_label = ttk.Label(top, text="Belum ada folder dipilih", width=48)
        self.folder_label.pack(side="left", padx=8)
        ttk.Button(top, text="Pilih Folder Output", command=self.choose_output).pack(side="left", padx=(8, 0))
        self.output_label = ttk.Label(top, text="Output: otomatis di folder cropped")
        self.output_label.pack(side="left", padx=8)

        info = ttk.Frame(root, padding=(10, 0, 10, 8))
        info.pack(fill="x")
        ttk.Label(
            info,
            text=("Petunjuk: pilih folder → tarik kotak crop pada pratinjau → klik 'Crop Semua Gambar'. "
                  "Area crop diterapkan secara proporsional pada semua gambar.")
        ).pack(anchor="w")
        self.status = ttk.Label(info, text="Pilih folder untuk mulai.", foreground="#1b5e20")
        self.status.pack(anchor="w", pady=(5, 0))

        self.canvas = tk.Canvas(root, bg="#20252b", highlightthickness=0, cursor="crosshair")
        self.canvas.pack(fill="both", expand=True, padx=10, pady=5)
        self.canvas.bind("<ButtonPress-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Configure>", self.on_resize)

        bottom = ttk.Frame(root, padding=10)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="◀ Sebelumnya", command=self.previous_image).pack(side="left")
        ttk.Button(bottom, text="Berikutnya ▶", command=self.next_image).pack(side="left", padx=5)
        ttk.Button(bottom, text="Hapus Kotak Crop", command=self.clear_crop).pack(side="left", padx=12)
        self.crop_button = ttk.Button(bottom, text="Crop Semua Gambar", command=self.crop_all)
        self.crop_button.pack(side="right")
        self.counter = ttk.Label(bottom, text="0 / 0")
        self.counter.pack(side="right", padx=12)

    def choose_input(self):
        folder = filedialog.askdirectory(title="Pilih folder screenshot CCTV")
        if not folder:
            return
        self.input_dir = folder
        self.files = sorted(
            os.path.join(folder, f) for f in os.listdir(folder)
            if os.path.isfile(os.path.join(folder, f)) and f.lower().endswith(SUPPORTED)
        )
        self.index = 0
        self.crop_rel = None
        self.folder_label.config(text=os.path.basename(folder) or folder)
        if not self.files:
            self.current_image = None
            self.canvas.delete("all")
            self.status.config(text="Tidak ditemukan file gambar yang didukung.")
            self.counter.config(text="0 / 0")
            messagebox.showwarning("Tidak ada gambar", "Folder tersebut tidak berisi JPG, PNG, WEBP, BMP, atau TIFF.")
            return
        if not self.output_dir:
            self.output_dir = os.path.join(folder, "cropped")
            self.output_label.config(text="Output: " + self.output_dir)
        self.show_image()

    def choose_output(self):
        folder = filedialog.askdirectory(title="Pilih folder untuk menyimpan hasil crop")
        if folder:
            self.output_dir = folder
            self.output_label.config(text="Output: " + folder)

    def show_image(self):
        if not self.files:
            return
        path = self.files[self.index]
        try:
            self.current_image = Image.open(path).convert("RGB")
            self.render_preview()
            self.counter.config(text=f"{self.index + 1} / {len(self.files)}")
            self.status.config(
                text=f"{os.path.basename(path)} — {self.current_image.width} × {self.current_image.height}px"
                + (" | Area crop sudah dipilih." if self.crop_rel else " | Tarik mouse untuk memilih area crop.")
            )
        except Exception as exc:
            messagebox.showerror("Gagal membuka gambar", f"{path}\n\n{exc}")

    def render_preview(self):
        if self.current_image is None:
            return
        self.root.update_idletasks()
        cw = max(self.canvas.winfo_width(), 400)
        ch = max(self.canvas.winfo_height(), 300)
        iw, ih = self.current_image.size
        self.scale = min((cw - 30) / iw, (ch - 30) / ih)
        self.display_w = max(1, int(iw * self.scale))
        self.display_h = max(1, int(ih * self.scale))
        self.offset_x = (cw - self.display_w) // 2
        self.offset_y = (ch - self.display_h) // 2
        preview = self.current_image.resize((self.display_w, self.display_h), Image.Resampling.LANCZOS)
        self.preview_photo = ImageTk.PhotoImage(preview)
        self.canvas.delete("all")
        self.canvas.create_image(self.offset_x, self.offset_y, image=self.preview_photo, anchor="nw", tags="preview")
        if self.crop_rel:
            l, t, r, b = self.crop_rel
            self.rect_id = self.canvas.create_rectangle(
                self.offset_x + l * self.display_w, self.offset_y + t * self.display_h,
                self.offset_x + r * self.display_w, self.offset_y + b * self.display_h,
                outline="#00ff88", width=3
            )

    def on_resize(self, _event=None):
        if self.current_image is not None:
            self.render_preview()

    def point_in_image(self, x, y):
        x1, y1 = self.offset_x, self.offset_y
        x2, y2 = x1 + self.display_w, y1 + self.display_h
        return x1 <= x <= x2 and y1 <= y <= y2

    def clamp_point(self, x, y):
        x = min(max(x, self.offset_x), self.offset_x + self.display_w)
        y = min(max(y, self.offset_y), self.offset_y + self.display_h)
        return x, y

    def on_press(self, event):
        if self.current_image is None or not self.point_in_image(event.x, event.y):
            return
        self.start_xy = self.clamp_point(event.x, event.y)
        if self.rect_id:
            self.canvas.delete(self.rect_id)
            self.rect_id = None
        self.rect_id = self.canvas.create_rectangle(
            *self.start_xy, *self.start_xy, outline="#00ff88", width=3
        )

    def on_drag(self, event):
        if self.start_xy is None or not self.rect_id:
            return
        x, y = self.clamp_point(event.x, event.y)
        self.canvas.coords(self.rect_id, self.start_xy[0], self.start_xy[1], x, y)

    def on_release(self, event):
        if self.start_xy is None or self.current_image is None:
            return
        x, y = self.clamp_point(event.x, event.y)
        x1, y1 = self.start_xy
        left, right = sorted((x1, x))
        top, bottom = sorted((y1, y))
        self.start_xy = None
        if right - left < 8 or bottom - top < 8:
            self.clear_crop()
            return
        self.crop_rel = (
            (left - self.offset_x) / self.display_w,
            (top - self.offset_y) / self.display_h,
            (right - self.offset_x) / self.display_w,
            (bottom - self.offset_y) / self.display_h,
        )
        self.render_preview()
        self.status.config(text="Area crop dipilih. Klik 'Crop Semua Gambar' untuk memproses folder.")

    def clear_crop(self):
        self.crop_rel = None
        if self.current_image is not None:
            self.render_preview()
            self.status.config(text="Area crop dihapus. Tarik mouse untuk memilih area baru.")

    def previous_image(self):
        if self.files:
            self.index = (self.index - 1) % len(self.files)
            self.show_image()

    def next_image(self):
        if self.files:
            self.index = (self.index + 1) % len(self.files)
            self.show_image()

    def crop_all(self):
        if not self.files:
            messagebox.showwarning("Folder kosong", "Pilih folder gambar terlebih dahulu.")
            return
        if not self.crop_rel:
            messagebox.showwarning("Area crop belum dipilih", "Tarik mouse pada pratinjau untuk menentukan area lalu lintas.")
            return
        if not self.output_dir:
            self.output_dir = os.path.join(self.input_dir, "cropped")
        os.makedirs(self.output_dir, exist_ok=True)
        l, t, r, b = self.crop_rel
        done, failed = 0, []
        self.crop_button.config(state="disabled")
        self.status.config(text="Sedang memproses gambar...")
        self.root.update_idletasks()
        for path in self.files:
            try:
                with Image.open(path) as im:
                    im = im.convert("RGB")
                    w, h = im.size
                    box = (
                        max(0, min(w - 1, round(l * w))),
                        max(0, min(h - 1, round(t * h))),
                        max(1, min(w, round(r * w))),
                        max(1, min(h, round(b * h))),
                    )
                    if box[2] <= box[0] or box[3] <= box[1]:
                        raise ValueError("Area crop tidak valid untuk ukuran gambar ini.")
                    cropped = im.crop(box)
                    stem = os.path.splitext(os.path.basename(path))[0]
                    out_path = os.path.join(self.output_dir, stem + "_crop.jpg")
                    cropped.save(out_path, "JPEG", quality=95, optimize=True)
                    done += 1
            except Exception as exc:
                failed.append(f"{os.path.basename(path)}: {exc}")
        self.crop_button.config(state="normal")
        msg = f"Selesai: {done} gambar disimpan di:\n{self.output_dir}"
        if failed:
            msg += f"\n\nGagal memproses {len(failed)} gambar. Contoh:\n" + "\n".join(failed[:5])
        self.status.config(text=f"Selesai. Berhasil: {done}; gagal: {len(failed)}.")
        messagebox.showinfo("Proses crop selesai", msg)


if __name__ == "__main__":
    root = tk.Tk()
    app = TrafficCropper(root)
    root.mainloop()
